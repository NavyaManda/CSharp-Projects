﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using business;
using Database;

namespace NMandahw3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }





        private void button1_Click_1(object sender, EventArgs e)
        {
            Btransaction bTR = new Btransaction();
            Transaction tr = new Transaction();
            tr.transactionID = Convert.ToInt32(custid.Text);
            tr.custName = Cname.Text;
            tr.softName = listBox1.SelectedItem.ToString();

            tr.setupOption = "No";
            if (addsetup.Checked == true)
            {
                tr.setupOption = "Yes";
            }
            tr.date = String.Empty;
            if (dateTimePicker1.Enabled == true)
            {
                tr.date = dateTimePicker1.Value.ToShortDateString();
            }


            tr.Nlicense = Convert.ToInt32(numlicense.Text);
            
            tr.charge = tr.calculatecharge();
            tr.setupfee = tr.setupFee();
            tr.tcharge = tr.totalcharge();
            //tran.licenseCheck += Onlicensecheck;
            bTR.insert(tr);
           // listBox2.Items.Add(tr);

            listBox2.Items.Add("Customer Name: " + tr.custName);
               listBox2.Items.Add("Transaction ID" + tr.transactionID);
               listBox2.Items.Add("Software Name" + tr.softName);
               listBox2.Items.Add("setup option" + tr.setupOption);
                      listBox2.Items.Add("setup fee" + tr.setupfee);
            listBox2.Items.Add( "setup date" + tr.date);
            listBox2.Items.Add( " charge" + tr.charge );
            listBox2.Items.Add(" total charge" + tr.tcharge);
            listBox2.Items.Add( "Number of License" + tr.Nlicense);
            // listBox2.Items.Add("Customer Name: " + softwareSales.customerName + "  " + " Order Date" + softwareSales.transactiondDate + "   " + "Software Package: " + softWare + "  " + "Total charge: " + softwareSales.totalCharges + "  SetupFee: " + setUpFee + " TrainingFee: " + trainFee + "   " + "Charge:" + licenseCost);


        }
        void Onlicensecheck(object sender, EventArgs e)
        {
            MessageBox.Show("Please notify technical support. This sale requires more than 20 installations");

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = null;
            this.dataGridView1.Rows.Clear();
            Transaction aTransaction = new Transaction();
            Btransaction bTR = new Btransaction();
            List<Transaction> aSale = new List<Transaction>();
            aSale = bTR.GetAllTransaction();

            dataGridView1.ColumnCount = 9;
            dataGridView1.Columns[0].Name = "transactionID";
            dataGridView1.Columns[1].Name = "CustomerName";
            dataGridView1.Columns[2].Name = "nooflicense";
            dataGridView1.Columns[3].Name = "software";
            dataGridView1.Columns[4].Name = "setupdate";
            dataGridView1.Columns[5].Name = "charge";
            dataGridView1.Columns[6].Name = "tcharge";
            dataGridView1.Columns[7].Name = "setupoption";
            dataGridView1.Columns[8].Name = "setupfee";

            foreach (Transaction aSecond in aSale)
            {
                dataGridView1.Rows.Add(aSecond.transactionID, aSecond.custName,
                    aSecond.Nlicense, aSecond.softName, aSecond.date, aSecond.charge, aSecond.tcharge, aSecond.setupOption, aSecond.setupfee);
            }

            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int transactionID = Convert.ToInt32(custid.Text);
            
            Btransaction bTR = new Btransaction();
            bTR.cancelTran(transactionID);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Btransaction TBL = new Btransaction();
            List<Transaction> list = TBL.GetAllTransaction();
            this.dataGridView1.DataSource = null;
            this.dataGridView1.Rows.Clear();
            dataGridView1.ColumnCount = 9;
            dataGridView1.Columns[0].Name = "transactionID";
            dataGridView1.Columns[1].Name = "CustomerName";
            dataGridView1.Columns[2].Name = "nooflicense";
            dataGridView1.Columns[3].Name = "software";
            dataGridView1.Columns[4].Name = "setupdate";
            dataGridView1.Columns[5].Name = "charge";
            dataGridView1.Columns[6].Name = "tcharge";
            dataGridView1.Columns[7].Name = "setupoption";
            dataGridView1.Columns[8].Name = "setupfee";

            foreach (Transaction x in list)
            {
                dataGridView1.Rows.Add(x.transactionID, x.custName,
                    x.Nlicense, x.softName, x.date, x.charge, x.tcharge, x.setupOption, x.setupfee);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int transactionID=Convert.ToInt32(custid.Text);
            Transaction t = new Transaction();
            Btransaction bTR = new Btransaction();
            t=bTR.getTransaction(transactionID);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            int trId = Convert.ToInt32(custid.Text);
            Transaction tran = new Transaction();
            Btransaction btran = new Btransaction();
            tran = btran.getTransaction(trId);
            if (addsetup.Checked)
            {
                tran.setupOption = "YES";
                tran.setupfee = Convert.ToInt32(numlicense.Text) * 500;
            }
            else
            {
                tran.setupOption = "NO";
                tran.setupfee = 0;
            }
            tran.Nlicense = int.Parse(numlicense.Text);

            tran.tcharge = tran.charge + Convert.ToInt32(numlicense.Text) * 500;
            btran.updateTransaction(tran);

        }






    }

}


