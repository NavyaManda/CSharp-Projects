﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Database;
using business;

namespace business
{
    public class Btransaction
    {
        //private salessoftwareEntities commonContext;
        TransactionDB tDB = new TransactionDB();
        public void insert(Transaction T)
        {
            if (T.Nlicense > 20)
                T.RaiselicenseCheck(EventArgs.Empty);
            try
            {
                Sale s = new Sale();
                s.transactionID = T.transactionID;
                s.CustomerName = T.custName;
                s.nooflicense = T.Nlicense;//assigning  class values to table values
                s.software = T.softName;
                s.setupdate = T.date;
                s.charge = (float)T.charge;
                s.tcharge = (float)T.tcharge;
                s.setupoption = T.setupOption;
                s.setupfee = (float)T.setupfee;

                tDB.saveRecord(s);

            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public List<Transaction> GetAllTransaction()
        {
            List<Transaction> listTran=new List<Transaction>();
            List<Sale> list;
            try
            {
                
                list = tDB.getAllSales();
                foreach (var x in list)
                {
                    Transaction t = new Transaction();
                    t.transactionID = x.transactionID;
                    t.Nlicense = x.nooflicense;
                    t.setupfee = (double)x.setupfee;
                    t.softName = x.software;
                    t.tcharge = x.tcharge;
                    t.custName = x.CustomerName;
                    t.charge = x.charge;
                    t.date = x.setupdate;
                    t.setupOption = x.setupoption;

                    listTran.Add(t);
                }
                return listTran;
            }

            catch (Exception ex)
            {
                throw new ArgumentException("An error occured when trying to access actor data ", ex);
            }
        }
        public void updateTransaction(Transaction t)
        {
            Sale s = new Sale();
            s.transactionID = t.transactionID;
            s.CustomerName = t.custName;
            s.software = t.softName;
            s.nooflicense = t.Nlicense;
            s.setupoption = t.setupOption;
            s.setupfee = t.setupfee;
            s.setupdate = t.date;
            s.charge = t.charge;
            s.tcharge = t.tcharge;
            tDB.updateSale(s);
        }
        public Transaction getTransaction(int tId)
        {
            Sale sale = new Sale();
            Transaction tr = new Transaction();
            sale = tDB.getTransById(tId);
            tr.transactionID = sale.transactionID;
            tr.Nlicense = sale.nooflicense;
            tr.setupfee = (float)sale.setupfee;
            tr.softName = sale.software;
            tr.tcharge = sale.tcharge;
            tr.custName = sale.CustomerName;
            tr.charge = sale.charge;
            tr.date = sale.setupdate;
            tr.setupOption = sale.setupoption;
            return tr;
        }
        public void cancelTran(int tId)
        {
            tDB.cancel(tId);
        }
    }
}
