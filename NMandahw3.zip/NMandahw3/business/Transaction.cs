﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business
{
    public class Transaction
    {

        public int transactionID { set; get; }
        public string custName { set; get; }
        public string softName { set; get; }
        public int Nlicense { set; get; }
        public string setupOption { set; get; }
        public double setupfee { set; get; }
        public string date { set; get; }
        public double charge { set; get; }
        public double tcharge { set; get; }
        public double calculatecharge()
        {
            
            switch (softName)
            {
                case "Sales Management":
                    charge = 2000 * Nlicense;

                    break;
                case "Backup Manager":
                    charge = 800 * Nlicense;
                    break;
                case "Payroll Solutions":
                    charge = 4500 * Nlicense;
                    break;
                case "EasyMeeting":
                    charge = 1000 * Nlicense;
                    break;
            }
            return charge;

        }
        public double setupFee()
        {
            if (setupOption == "Yes")
            {
                setupfee = 500 * Nlicense;
            }
            return setupfee;
        }
        public double totalcharge()
        {
            return tcharge = setupfee + charge;
        }

        public void RaiselicenseCheck(EventArgs eventArgs)
        {
            
        }
    }
}
