﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class TransactionDB
    {

        public void saveRecord(Sale s)
        {
            using (salessoftwareEntities data = new salessoftwareEntities())
            {
                data.Sales.Add(s);
                data.SaveChanges();

            }
        }
        public void cancel(int tranID)
        {
            try
            {
                using (var data = new salessoftwareEntities())
                {

                    var Table = (from a in data.Sales
                                 where a.transactionID == tranID
                                 select a).First();

                    data.Sales.Remove(Table);
                    data.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException("An error occured when trying to access sales data ", ex);
            }

        }
        public List<Sale> getAllSales()
        {
            using (var commonContext = new salessoftwareEntities())
            {
                var query = from a in commonContext.Sales
                            select a;

                return query.ToList();
            }
        }


        public void updateSale(Sale s)
        {
            using (salessoftwareEntities commonContext = new salessoftwareEntities())
            {
                commonContext.Sales.Attach(s);
                commonContext.Entry(s).State = EntityState.Modified;
                commonContext.SaveChanges();
            }
        }

        public Sale getTransById(int tId)
        {
            using (salessoftwareEntities ctx = new salessoftwareEntities())
            {
                Sale sale = ctx.Sales.Single(s => s.transactionID == tId);
                return sale;
            }
        }
    }
}
