﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintedTShirts
{
    public class Transactions<T>
    {
        public List<T> Transctions { get; set; }

        public Transactions()
        {
            Transctions = new List<T>();
        }
        public void AddTransaction(T transaction)
        {
            Transctions.Add(transaction);
        }
    }
}
