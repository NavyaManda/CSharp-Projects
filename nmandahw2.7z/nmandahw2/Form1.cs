﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrintedTShirts
{
    public partial class Form1 : Form
    {
        private List<Customization> customizations;
        private List<Order> AllOrders;
        private Order CurrentOrder;
        private bool isOrderStarted = false;
        public Form1()
        {
            InitializeComponent();
            Init();
        }

        public void Init()
        {
            AllOrders = new List<Order>();
            customizationList.DataSource = new List<string> { "Printed", "Screen Printed", "Embroidered" };
            listColor.DataSource = new List<string> {"Red", "Black", "Green" };
            listProductTypes.DataSource = new List<string> { "Short Sleeve T-Shirt", "Long Sleev T-Shirt", "Sweatshirt", "Polo"};
            listSizes.DataSource = new List<string> { "S", "M", "L", "XL"};

        }


        private void btnStartOrder_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textName.Text))
                {
                    MessageBox.Show("Enter Customer Name!");
                    return;
                }

                if (string.IsNullOrEmpty(txtCustomizationText.Text))
                {
                    MessageBox.Show("Enter Customization Text!");
                    return;
                }
                textName.Enabled = false;
                dateTimePicker1.Enabled = false;
                customizationList.Enabled = false;
                txtCustomizationText.Enabled = false;
                listColor.Enabled = false;
                CurrentOrder = new Order();
                CurrentOrder.CustomerName = textName.Text;


                CurrentOrder.Customization = new Customization
                {
                    Type = customizationList.SelectedItem.ToString(),
                    Text = txtCustomizationText.Text,
                    price = GetCustomizationPrice(customizationList.SelectedItem.ToString())

                };
                CurrentOrder.OrderDate = dateTimePicker1.Value.Date;
                isOrderStarted = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private decimal GetCustomizationPrice(string v)
        {
            if (v == "Printed")
                return 10;
            if (v == "Screen Printed")
                return 6;
            if (v == "Embroidered")
                return 12;

            return 0;
        }

        private void addItemBt_Click(object sender, EventArgs e)
        {
            try
            {

                if (!isOrderStarted)
                {
                    MessageBox.Show("Please start the order");
                    return;
                }

                if (numericUpDownQuant.Value < 1)
                {
                    MessageBox.Show("Provide valid quantity!");
                    return;
                }

                var orderItem = new OrderItem
                {
                    Type = listProductTypes.SelectedItem.ToString(),
                    Price = GetProductPrice(listProductTypes.SelectedItem.ToString()),
                    Quantity = numericUpDownQuant.Value,
                    Size = listSizes.SelectedItem.ToString()
                };

                CurrentOrder.AddItem(orderItem);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private decimal GetProductPrice(string v)
        {
            if (v == "Short Sleeve T-Shirt")
                return 10.5m;
            if (v == "Long Sleev T-Shirt")
                return 9.5m;
            if (v == "Sweatshirt")
                return 20;
            if (v == "Polo")
                return 18;

            return 0;
        }

        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                AllOrders.Add(CurrentOrder);
                richTextSummary.Text = CurrentOrder.GetInvoice();
                textName.Enabled = true;
                dateTimePicker1.Enabled = true;
                customizationList.Enabled = true;
                txtCustomizationText.Enabled = true;
                listColor.Enabled = true;
                isOrderStarted = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void buttonDisplayOrder_Click(object sender, EventArgs e)
        {
            try
            {

                richTextSummary.Text = string.Empty;
                richTextSummary.Text = GetOrdersSummary();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private string GetOrdersSummary()
        {
            StringBuilder summary = new StringBuilder();
            var count = 1;
            foreach (var item in AllOrders)
            {
                summary.Append("Order No: " + count);
                summary.AppendLine();
                summary.AppendLine("Customer Name : " + item.CustomerName);
                summary.AppendLine();
                summary.AppendLine("Total Items : " + item.Items.Count());
                summary.AppendLine();
                summary.AppendLine("Total Charge : " + item.GetTotalCharge());
                summary.AppendLine();
                summary.Append("----------------------");
                summary.AppendLine();
                count++;

            }
            return summary.ToString();
        }

        private void buttonCustReport_Click(object sender, EventArgs e)
        {
            try
            {
                richTextSummary.Text = string.Empty;
                richTextSummary.Text = GetOrdersSummary();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

    }
}
