﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintedTShirts
{
    public class Order
    {
        public Order()
        {
            this.Items = new List<OrderItem>();
        }
        public string CustomerName { get; set; }
        public DateTime OrderDate { get; set; }
        public Customization Customization { get; set; }
        public List<OrderItem> Items { get; set; }
        public void AddItem(OrderItem item)
        {
            Items.Add(item);
        }

        public void AddCustomization(Customization cust)
        {
            Customization = cust;
        }

        public decimal GetCusomizationFee()
        {
            return Customization.price;
        }

        internal string GetInvoice()
        {
            StringBuilder invoice = new StringBuilder();
            invoice.Append("Customer Name: " + this.CustomerName);
            invoice.AppendLine();
            invoice.Append("Order Date: " + this.OrderDate.ToString());
            invoice.AppendLine();
            invoice.Append("CustomizationType: " + this.Customization.Type);
            invoice.AppendLine();
            invoice.Append("CustomizationText: " + this.Customization.Text);
            invoice.AppendLine();
            invoice.Append("CustomizationColor: " + this.Customization.Color);
            invoice.AppendLine();
            invoice.Append("Order Iitems");
            invoice.AppendLine();
            invoice.Append(GetOrderList());
            var subtotal = this.Items.Sum(x => x.Price);
            invoice.Append("SubTotal: " + subtotal);
            invoice.AppendLine();
            invoice.AppendLine("Total: " + subtotal+ Customization.price);
            return invoice.ToString();
        }

        private string GetOrderList()
        {
            var orderSummary = new StringBuilder();
            foreach(var item in Items.OrderBy(x => x.Type))
            {
                orderSummary.Append(item.Type + " " + item.Size + "" + item.Price);
                orderSummary.AppendLine();
            }

            return orderSummary.ToString();
        }

        internal decimal GetTotalCharge()
        {
            return this.Items.Sum(x => x.Price) + Customization.price;
        }
    }
}
