﻿namespace PrintedTShirts
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.customizationList = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCustomizationText = new System.Windows.Forms.TextBox();
            this.btnStartOrder = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.listColor = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.listProductTypes = new System.Windows.Forms.ListBox();
            this.listSizes = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.numericUpDownQuant = new System.Windows.Forms.NumericUpDown();
            this.addItemBt = new System.Windows.Forms.Button();
            this.buttonSubmit = new System.Windows.Forms.Button();
            this.buttonDisplayOrder = new System.Windows.Forms.Button();
            this.buttonCustReport = new System.Windows.Forms.Button();
            this.richTextSummary = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuant)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Name: ";
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(135, 6);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(100, 20);
            this.textName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(315, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Order Date: ";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(424, 6);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Customization Type:";
            // 
            // customizationList
            // 
            this.customizationList.FormattingEnabled = true;
            this.customizationList.Location = new System.Drawing.Point(135, 51);
            this.customizationList.Name = "customizationList";
            this.customizationList.Size = new System.Drawing.Size(130, 95);
            this.customizationList.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Customization Text";
            // 
            // txtCustomizationText
            // 
            this.txtCustomizationText.Location = new System.Drawing.Point(135, 165);
            this.txtCustomizationText.Name = "txtCustomizationText";
            this.txtCustomizationText.Size = new System.Drawing.Size(200, 20);
            this.txtCustomizationText.TabIndex = 7;
            // 
            // btnStartOrder
            // 
            this.btnStartOrder.Location = new System.Drawing.Point(387, 165);
            this.btnStartOrder.Name = "btnStartOrder";
            this.btnStartOrder.Size = new System.Drawing.Size(75, 23);
            this.btnStartOrder.TabIndex = 8;
            this.btnStartOrder.Text = "Start Order";
            this.btnStartOrder.UseVisualStyleBackColor = true;
            this.btnStartOrder.Click += new System.EventHandler(this.btnStartOrder_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(285, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Customization Color";
            // 
            // listColor
            // 
            this.listColor.FormattingEnabled = true;
            this.listColor.Location = new System.Drawing.Point(424, 51);
            this.listColor.Name = "listColor";
            this.listColor.Size = new System.Drawing.Size(120, 95);
            this.listColor.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 237);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Product Type: ";
            // 
            // listProductTypes
            // 
            this.listProductTypes.FormattingEnabled = true;
            this.listProductTypes.Location = new System.Drawing.Point(145, 237);
            this.listProductTypes.Name = "listProductTypes";
            this.listProductTypes.Size = new System.Drawing.Size(120, 95);
            this.listProductTypes.TabIndex = 13;
            // 
            // listSizes
            // 
            this.listSizes.FormattingEnabled = true;
            this.listSizes.Location = new System.Drawing.Point(424, 237);
            this.listSizes.Name = "listSizes";
            this.listSizes.Size = new System.Drawing.Size(120, 95);
            this.listSizes.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(347, 249);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Size: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 359);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Quantity";
            // 
            // numericUpDownQuant
            // 
            this.numericUpDownQuant.Location = new System.Drawing.Point(135, 359);
            this.numericUpDownQuant.Name = "numericUpDownQuant";
            this.numericUpDownQuant.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownQuant.TabIndex = 17;
            // 
            // addItemBt
            // 
            this.addItemBt.Location = new System.Drawing.Point(340, 359);
            this.addItemBt.Name = "addItemBt";
            this.addItemBt.Size = new System.Drawing.Size(75, 23);
            this.addItemBt.TabIndex = 18;
            this.addItemBt.Text = "Add Item";
            this.addItemBt.UseVisualStyleBackColor = true;
            this.addItemBt.Click += new System.EventHandler(this.addItemBt_Click);
            // 
            // buttonSubmit
            // 
            this.buttonSubmit.Location = new System.Drawing.Point(135, 428);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.Size = new System.Drawing.Size(75, 23);
            this.buttonSubmit.TabIndex = 19;
            this.buttonSubmit.Text = "Submit Order";
            this.buttonSubmit.UseVisualStyleBackColor = true;
            this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // buttonDisplayOrder
            // 
            this.buttonDisplayOrder.Location = new System.Drawing.Point(288, 428);
            this.buttonDisplayOrder.Name = "buttonDisplayOrder";
            this.buttonDisplayOrder.Size = new System.Drawing.Size(106, 23);
            this.buttonDisplayOrder.TabIndex = 20;
            this.buttonDisplayOrder.Text = "Display Order Report";
            this.buttonDisplayOrder.UseVisualStyleBackColor = true;
            this.buttonDisplayOrder.Click += new System.EventHandler(this.buttonDisplayOrder_Click);
            // 
            // buttonCustReport
            // 
            this.buttonCustReport.Location = new System.Drawing.Point(470, 428);
            this.buttonCustReport.Name = "buttonCustReport";
            this.buttonCustReport.Size = new System.Drawing.Size(126, 29);
            this.buttonCustReport.TabIndex = 21;
            this.buttonCustReport.Text = "Display Customization Report";
            this.buttonCustReport.UseVisualStyleBackColor = true;
            this.buttonCustReport.Click += new System.EventHandler(this.buttonCustReport_Click);
            // 
            // richTextSummary
            // 
            this.richTextSummary.Location = new System.Drawing.Point(634, 51);
            this.richTextSummary.Name = "richTextSummary";
            this.richTextSummary.Size = new System.Drawing.Size(166, 400);
            this.richTextSummary.TabIndex = 22;
            this.richTextSummary.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(634, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Summary";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(812, 495);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.richTextSummary);
            this.Controls.Add(this.buttonCustReport);
            this.Controls.Add(this.buttonDisplayOrder);
            this.Controls.Add(this.buttonSubmit);
            this.Controls.Add(this.addItemBt);
            this.Controls.Add(this.numericUpDownQuant);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.listSizes);
            this.Controls.Add(this.listProductTypes);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.listColor);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnStartOrder);
            this.Controls.Add(this.txtCustomizationText);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.customizationList);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuant)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox customizationList;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCustomizationText;
        private System.Windows.Forms.Button btnStartOrder;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listColor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox listProductTypes;
        private System.Windows.Forms.ListBox listSizes;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numericUpDownQuant;
        private System.Windows.Forms.Button addItemBt;
        private System.Windows.Forms.Button buttonSubmit;
        private System.Windows.Forms.Button buttonDisplayOrder;
        private System.Windows.Forms.Button buttonCustReport;
        private System.Windows.Forms.RichTextBox richTextSummary;
        private System.Windows.Forms.Label label9;
    }
}

